import sys
from Vehiculo import Vehiculo

#Herencia
class Patineta(Vehiculo):
    
    #Atributo Clase
    nivel_carga = 100

    def __init__(self,codigo,fecha_compra,codigo_gps): #Constructor
        
        
        #Invocar el constructor del padre
        Vehiculo.__init__(self,codigo,fecha_compra,codigo_gps)

        #Adicionamos los atributos de instancia de la subclase
        pass #cuando no tenemos atributos de instancia, para que no salga un posible error
 
    
    def Reparar(self):
        return("Reparando Patineta")
