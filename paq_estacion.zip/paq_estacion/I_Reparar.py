'''
Interfaces are not natively supported by Python,
although abstract classes and abstract methods can be used to go around this.
 there is no explicit 'interface' keyword in Python for establishing an interface.
 In Python, an abstract class with solely abstract methods
 is used to construct an interface.

Hay dos tipos de interfaces :informales(herencia sencilladesde la interface y nada es abstracto.
en la subclase se hace el override (python no tiene esta instruccion tampoco). es menos restrictiva)
y formales()

Acá veremos la formal
ABC, Abstract Base Class is a simple interface or base class defined as
an abstract class in nature, and the abstract class has certain abstract methods

'''
import abc
from abc import ABC, abstractmethod

class I_Reparar(abc.ABC): 
    #Decorador para hacer los métodos abstractos 
    #Decorador: pattern that enables users to extend an objects functionality without changing the objects structure.

    @abc.abstractmethod 
    def Reparar(self):
        pass
