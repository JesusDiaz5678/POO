class Usuario:

    #Atributos de clase
    posee_veh = False
    vehiculo = []

    def __init__(self,nro_id,nombre,telefono):

        #Atributos de instancia
        self.nro_id = nro_id
        self.nombre = nombre
        self.telefono = telefono
