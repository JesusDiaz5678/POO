import sys
from Patineta import Patineta
from Bicicleta import Bicicleta
from Usuario import Usuario 


class Estacion:   #l_vehiculos[[B,B,B,B,B,B,B,B,B,B][P,P,P,P,P,P,P,P,P,P,P]]

    def __init__(self,nombre, direccion,l_vehiculos = []):
        self.nombre = nombre
        self.direccion = direccion
        self.l_vehiculos = l_vehiculos

    def __str__(self): 
        return str(self.l_vehiculos)


    def Entregar_Vehiculo(self, ciudadano, vehiculo):
        try:                
            if type(vehiculo) == Bicicleta:
                if len(self.l_vehiculos[0]) > 0 and ciudadano.posee_veh == False:
                    ciudadano.vehiculo.append(self.l_vehiculos[0].pop(0))
                    ciudadano.posee_veh = True
                    return("Se le ha entregado la bicicleta",ciudadano.vehiculo[0].codigo,"al ciudadano")
                else:
                    return("El ciudadano ya tiene un vehículo o la estación no tiene bicicletas")
    
            elif type(vehiculo) == Patineta:
                if len(self.l_vehiculos[1]) > 0 and ciudadano.posee_veh == False:
                    ciudadano.vehiculo.append(self.l_vehiculos[1].pop(0))
                    ciudadano.posee_veh = True
                    return("Se le ha entregado la patineta",ciudadano.vehiculo[0].codigo,"al ciudadano")
                else:
                    return("El ciudadano ya tiene un vehículo o la estación no tiene patinetas")

            else:
                return ("Es un error")
            
        except Exception as error:
            return("Ocurrió un error en el método Entregar_Vehiculo ==>", error)


    def Recibir_Vehiculo(self, ciudadano):
        try:
            if type(ciudadano.vehiculo[0]) == Bicicleta and ciudadano.posee_veh == True:
                    self.l_vehiculos[0].append(ciudadano.vehiculo.pop(0))
                    ciudadano.posee_veh = False
                    return("Ha devuelto la bicicleta ", self.l_vehiculos[0][-1].codigo )

            elif type(ciudadano.vehiculo[0]) == Patineta and ciudadano.posee_veh == True:
                    self.l_vehiculos[1].append(ciudadano.vehiculo.pop(0))
                    ciudadano.posee_veh = False
                    return("Ha devueto la patineta",self.l_vehiculos[1][-1].codigo, "al ciudadano")

            else:
                return ("Es un error, puede ser que el ciudadano no tenga vehículos")

        except:
            return("Ocurrió un error en el método Recibir_Veh", error)
