import sys
from Vehiculo import Vehiculo

class Bicicleta(Vehiculo):
    #Atributo Clase
    pass

    def __init__(self,codigo,fecha_compra,codigo_gps, nro_cambios): #Constructor

        #Invocar el constructor del padre
        Vehiculo.__init__(self,codigo,fecha_compra,codigo_gps)
        
        #Atributos de instancia de la subclase
        self.nro_cambios = nro_cambios


    def Reparar(self):
        print('Reparando Bicicleta')
