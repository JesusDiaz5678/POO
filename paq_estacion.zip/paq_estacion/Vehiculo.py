import sys
import abc
import I_Reparar
from abc import ABC, abstractmethod
from I_Reparar import I_Reparar

class Vehiculo(I_Reparar):
    #Las clases tienen dos tipos de atributos: 1. Atributos de clase, 2. Atributos de instancia(constructor)

    #Atributo de clase
        #text codigo

    #Constructor
    def __init__(self,codigo,fecha_compra,codigo_gps):
        #Atributos de instancia
        self.codigo = codigo
        self.fecha_compra = fecha_compra
        self.codigo_gps = codigo_gps

    def __repr__(self):
        return self.codigo

    @abstractmethod #No hay override
    def Reparar(self):
        pass
