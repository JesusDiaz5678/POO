import sys
from Patineta import Patineta
from Bicicleta import Bicicleta
from Usuario import Usuario 
from Estacion import Estacion


b1 = Bicicleta("B001","01/01/2019","GPS01",7)
b2 = Bicicleta("B002","01/05/2019","GPS02",7)

p1 = Patineta("P001","01/04/2021","GPS03")
p2 = Patineta("P002","01/11/2020","GPS04")

l_veh = [[b1,b2],[p1,p2]]

U1 = Usuario(545646,"Pedro Perez", 1321321)
E1 = Estacion("Estadio", "Carrera 70", l_veh)

print(E1.l_vehiculos)


#voy crear vehiculos Dummy para usarlos en el método entregar vehiculo

b_dum=Bicicleta("","","",0)
p_dum=Patineta("","","")

print(E1.Entregar_Vehiculo(U1,b_dum))

print(E1.l_vehiculos)

print(p1.Reparar())


